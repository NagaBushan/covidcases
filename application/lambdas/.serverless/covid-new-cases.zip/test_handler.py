import mock
from mock.mock import patch
from .handler import handle
import pytest
import os
class TestHandler:
    @pytest.fixture
    def event(self):
        return None

    @pytest.fixture
    def context(self):
        return None


    @mock.patch.dict(os.environ, {'COVID_CASES_API': 'http://www.test/url'})
    @patch('covid_new_cases.handler.get_covid_cases')
    def test_lambda_handler(self, event, context, get_mock):
        get_mock.return_value.status_code = 200
        result = handle(event, context)
        print(result)
        # assert_valid_schema(result, 'vendor_list.json')
